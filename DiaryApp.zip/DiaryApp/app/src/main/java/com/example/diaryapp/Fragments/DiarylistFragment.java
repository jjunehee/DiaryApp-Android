package com.example.diaryapp.Fragments;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ImageButton;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.diaryapp.Adapters.DiaryAdapter;
import com.example.diaryapp.EditpageActivity;
import com.example.diaryapp.Models.DiaryData;
import com.example.diaryapp.R;
import com.example.diaryapp.ReadpageActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class DiarylistFragment extends Fragment {

    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private ArrayList<DiaryData> diaryList = new ArrayList<DiaryData>();
    private DiaryAdapter mdiaryAdapter;
    private ImageButton writeButton;
    private TextView tv_mydiary;
    private Context context;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@Nullable LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_diarylist, container, false);

        context = container.getContext();

        long now = System.currentTimeMillis();
        Date mDate = new Date(now);
        SimpleDateFormat simpleDate = new SimpleDateFormat("yyyy년MM월dd일");
        String getTime = simpleDate.format(mDate);

        writeButton = view.findViewById(R.id.writeButton);
        writeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), EditpageActivity.class);
                intent.putExtra("date", getTime);
                intent.putExtra("context", ' ');
                intent.putExtra("title", ' ');
                intent.putExtra("mood", ' ');
                startActivity(intent);
            }
        });

        tv_mydiary = view.findViewById(R.id.tv_mydiarytitle);

        mRecyclerView = view.findViewById(R.id.rv_diary);

        setData();
        RecyclerViewSettings();

        return view;
    }

    private void RecyclerViewSettings() {
        mRecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(getContext());
        mRecyclerView.setLayoutManager(mLayoutManager);
        mdiaryAdapter = new DiaryAdapter(getActivity(), diaryList);
        mRecyclerView.setAdapter(mdiaryAdapter);
    }

    private void setData() {
        for(int i = 0; i < 15; i++) {
            diaryList.add(new DiaryData("오늘의 일기" + i, "행복해", "asdfqwerasdf", "2021.12.08"));
        }
    }

}