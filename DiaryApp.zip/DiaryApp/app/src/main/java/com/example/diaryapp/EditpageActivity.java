package com.example.diaryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import com.example.diaryapp.Fragments.DatePickerFragment;

public class EditpageActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    TextView Wdate;
    TextView spinnerview;
    Spinner spinner;
    String[] emotion;

    private String title;
    private String context;
    private String date;
    private String mood;
    private TextView ed_title;
    private TextView ed_date;
    private TextView ed_mood;
    private TextView ed_context;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editpage);

        Wdate = (TextView) findViewById(R.id.WtextView1);

        spinnerview = (TextView)findViewById(R.id.spinnerview);
        spinner = (Spinner)findViewById(R.id.spinner_emotion);

        spinner.setOnItemSelectedListener(this);

        emotion = new String[]{"선택하세요","행복해", "기뻐", "우울해", "화나"};

        ArrayAdapter<String> adapter =new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,emotion);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        Button exitbutton = findViewById(R.id.Wexitbutton);

        exitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });


        ed_title = findViewById(R.id.WeditText);
        ed_context = findViewById(R.id.editTextTextMultiLine);
        ed_date = findViewById(R.id.WtextView1);
        ed_mood = findViewById(R.id.spinnerview); //수정해야됌

        Intent intent = getIntent();
        date = intent.getExtras().getString("date");
        title = intent.getExtras().getString("title");
        context = intent.getExtras().getString("context");
        mood = intent.getExtras().getString("mood");

        ed_date.setText(date);
        ed_title.setText(title);
        ed_mood.setText(mood);
        ed_context.setText(context);

    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        spinnerview.setText(emotion[i]);
        if(spinnerview.getText().toString().equals("선택하세요")){
            spinnerview.setText("");
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        spinnerview.setText("");
    }

    public void showDatePicker(View view) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getSupportFragmentManager(),"datePicker");
    }

    public void processDatePickerResult(int year, int month, int day){
        String month_string = Integer.toString(month+1);
        String day_string = Integer.toString(day);
        String year_string = Integer.toString(year);
        String dateMessage = (year_string + "년" + month_string + "월" + day_string + "일");

        Toast toast = Toast.makeText(this,dateMessage+ " 선택됨",Toast.LENGTH_SHORT);
        toast.show();
        Wdate.setText(dateMessage);
    }

}
