package com.example.diaryapp.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.applandeo.materialcalendarview.CalendarView;
import com.applandeo.materialcalendarview.EventDay;
import com.applandeo.materialcalendarview.listeners.OnDayClickListener;
import com.example.diaryapp.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class EmojiFragment extends Fragment {
    private RecyclerView.LayoutManager mLayoutManager;
    private RecyclerView.Adapter mAdapter;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@Nullable LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_emoji, container, false);
        CalendarView calendarView = (CalendarView) view.findViewById(R.id.calendarView); //달력 전체
        List<EventDay> events = new ArrayList<>(); //event(emoji)목록
//        getDate() db 데이터 가져와야한다.

        //event(emoji) 설정
        Calendar calendar = Calendar.getInstance();
        events.add(new EventDay(calendar, R.drawable.book));
        calendar.set(2021, 11, 8); //month+1 = real month
        calendarView.setEvents(events);

        calendar = Calendar.getInstance();
        events.add(new EventDay(calendar, R.drawable.calendar));
        calendar.set(2021, 11, 9); //month+1 = real month
        calendarView.setEvents(events);

        calendar = Calendar.getInstance();
        events.add(new EventDay(calendar, R.drawable.calendar));
        calendarView.setEvents(events);

        //click 이벤트
        calendarView.setOnDayClickListener(new OnDayClickListener() {
            @Override
            public void onDayClick(EventDay eventDay) {
                Toast.makeText(getContext().getApplicationContext(), "클릭 테스트", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}
